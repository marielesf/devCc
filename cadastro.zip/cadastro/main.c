#include <stdio.h>
#include <stdlib.h>

struct cadastro {
char nome[30];
char sexo;
char datanascimento[10];
int idade;
char doencas[200];
}cad[10];


void cadastroP(int cod,int pos);

int main()
{ int menu;

    printf("1- Cadastrar Cliente\n 2- Buscar Cliente\n 3- Listar Clientes\n 4- Excluir Cliente\n");
    scanf("%d", &menu);
    switch (menu){
        case 1:
            cadastroP();
            break;
        case 2:
            //printf("2- Buscar Cliente\n");
            break;
        case 3:
            //printf("3- Listar Clientes\n");
            break;
        case  4:
            //printf("4- Excluir Cliente\n");
            break;
        default :
            printf ("Escolha invalida!\n");
    }
    return 0;
}

void cadastroP(int cod,int pos){ //Cadastro das pessoas
        int pos=0;
        printf("\nDigite seu nome: ");
        gets(cad[pos].nome);
        printf("\nDigite seu sexo F/M: ");
        gets(cad[pos].sexo);
        printf("\nDigite a data de nascimento: ");
        gets(cad[pos].datanascimento);
        printf("\nDigite sua idade: ");
        gets(cad[pos].idade);
        printf("Digite suas doen�as importantes:");
        gets(cad[pos].doencas);
}
